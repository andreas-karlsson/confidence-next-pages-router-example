# Changelog

## [0.12.1](https://github.com/spotify/confidence-resolver/compare/openfeature-provider-js-v0.12.0...openfeature-provider-js-v0.12.1) (2026-04-28)


### Bug Fixes

* **js:** strip resolveToken from RSC client bundle ([#388](https://github.com/spotify/confidence-resolver/issues/388)) ([f202f56](https://github.com/spotify/confidence-resolver/commit/f202f56f119faf791f26e0011c30ace259939f5e))
* surface apply_flags errors instead of swallowing ([#386](https://github.com/spotify/confidence-resolver/issues/386)) ([7785f9f](https://github.com/spotify/confidence-resolver/commit/7785f9ff116c8151daa70b9fbaab9e66d8e88794))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * rust-guest bumped from 0.1.22 to 0.1.23

## [0.12.0](https://github.com/spotify/confidence-resolver/compare/openfeature-provider-js-v0.11.2...openfeature-provider-js-v0.12.0) (2026-04-15)


### Features

* improve Prometheus metrics API ([#371](https://github.com/spotify/confidence-resolver/issues/371)) ([efb8c16](https://github.com/spotify/confidence-resolver/commit/efb8c16a4ca9659c60e4f69611c80d3addb4e3fa))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * rust-guest bumped from 0.1.21 to 0.1.22

## [0.11.2](https://github.com/spotify/confidence-resolver/compare/openfeature-provider-js-v0.11.1...openfeature-provider-js-v0.11.2) (2026-04-14)


### Bug Fixes

* free WASM guest request allocation in host functions ([#369](https://github.com/spotify/confidence-resolver/issues/369)) ([dd7ddac](https://github.com/spotify/confidence-resolver/commit/dd7ddac4e22e895c7b08b09064c9dc8bab54c716))

## [0.11.1](https://github.com/spotify/confidence-resolver/compare/openfeature-provider-js-v0.11.0...openfeature-provider-js-v0.11.1) (2026-03-26)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * rust-guest bumped from 0.1.20 to 0.1.21

## [0.11.0](https://github.com/spotify/confidence-resolver/compare/openfeature-provider-js-v0.10.1...openfeature-provider-js-v0.11.0) (2026-03-24)


### Features

* add register_resolve WASM export for SDK-side telemetry ([#354](https://github.com/spotify/confidence-resolver/issues/354)) ([31499bc](https://github.com/spotify/confidence-resolver/commit/31499bc911942ecd751b4a4a702f35ded41e9776))
* add resolver_version field to TelemetryData ([#346](https://github.com/spotify/confidence-resolver/issues/346)) ([10ab1c6](https://github.com/spotify/confidence-resolver/commit/10ab1c657cb830dc36f433d1dca0af73beecaa27))
* local prometheus sdk metrics ([#322](https://github.com/spotify/confidence-resolver/issues/322)) ([8b18119](https://github.com/spotify/confidence-resolver/commit/8b18119eae449afbe4a0815e8aab5f82888a8621))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * rust-guest bumped from 0.1.19 to 0.1.20

## [0.10.1](https://github.com/spotify/confidence-resolver/compare/openfeature-provider-js-v0.10.0...openfeature-provider-js-v0.10.1) (2026-03-12)


### Bug Fixes

* pass the sdk with the state to get it into telemetry ([#332](https://github.com/spotify/confidence-resolver/issues/332)) ([1f22c5f](https://github.com/spotify/confidence-resolver/commit/1f22c5fa38c4e8a7d56ea4616db94f9b991d41ab))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * rust-guest bumped from 0.1.18 to 0.1.19

## [0.10.0](https://github.com/spotify/confidence-resolver/compare/openfeature-provider-js-v0.9.1...openfeature-provider-js-v0.10.0) (2026-03-06)


### Features

* metrics in telemetry data ([#266](https://github.com/spotify/confidence-resolver/issues/266)) ([965eff6](https://github.com/spotify/confidence-resolver/commit/965eff60b6c0377336e6e86624a78f6f3a859f73))


### Bug Fixes

* **js:** increase state fetch stall timeout to 1s ([#293](https://github.com/spotify/confidence-resolver/issues/293)) ([f95da45](https://github.com/spotify/confidence-resolver/commit/f95da455ef338b3e43604f4a2d76d008c9e63496))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * rust-guest bumped from 0.1.17 to 0.1.18

## [0.9.1](https://github.com/spotify/confidence-resolver/compare/openfeature-provider-js-v0.9.0...openfeature-provider-js-v0.9.1) (2026-02-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * rust-guest bumped from 0.1.16 to 0.1.17

## [0.9.0](https://github.com/spotify/confidence-resolver/compare/openfeature-provider-js-v0.8.1...openfeature-provider-js-v0.9.0) (2026-02-19)


### Features

* Support for startsWith and endsWith ([#283](https://github.com/spotify/confidence-resolver/issues/283)) ([661c4ef](https://github.com/spotify/confidence-resolver/commit/661c4ef53b5d907bf079e632135723c2af7af0b9))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * rust-guest bumped from 0.1.15 to 0.1.16

## [0.8.1](https://github.com/spotify/confidence-resolver/compare/openfeature-provider-js-v0.8.0...openfeature-provider-js-v0.8.1) (2026-02-10)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * rust-guest bumped from 0.1.14 to 0.1.15

## [0.8.0](https://github.com/spotify/confidence-resolver/compare/openfeature-provider-js-v0.7.0...openfeature-provider-js-v0.8.0) (2026-01-27)


### Features

* **js:** add React support with useFlag and useFlagDetails hooks ([#246](https://github.com/spotify/confidence-resolver/issues/246)) ([d579a4c](https://github.com/spotify/confidence-resolver/commit/d579a4c8fe493ee3a92539203f21d1c03758c58e))
* **wasm:** add wasm API to apply previously resolved flags ([#235](https://github.com/spotify/confidence-resolver/issues/235)) ([79048f6](https://github.com/spotify/confidence-resolver/commit/79048f63a8c771eb98ecf478cab0b654aa745374))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * rust-guest bumped from 0.1.13 to 0.1.14

## [0.7.0](https://github.com/spotify/confidence-resolver/compare/openfeature-provider-js-v0.6.0...openfeature-provider-js-v0.7.0) (2026-01-22)


### Features

* inlined WASM for improved portability ([#243](https://github.com/spotify/confidence-resolver/issues/243)) ([8d86283](https://github.com/spotify/confidence-resolver/commit/8d862837244ffd9099bfeb56b42e203212e73a96))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * rust-guest bumped from 0.1.12 to 0.1.13

## [0.6.0](https://github.com/spotify/confidence-resolver/compare/openfeature-provider-js-v0.5.1...openfeature-provider-js-v0.6.0) (2026-01-15)


### Features

* **js:** add stateUpdateInterval option for configurable state polling ([#224](https://github.com/spotify/confidence-resolver/issues/224)) ([5687847](https://github.com/spotify/confidence-resolver/commit/56878478d3d508870ac0f3172f897c8728e8a85d))


### Bug Fixes

* prevent split bundle ([#212](https://github.com/spotify/confidence-resolver/issues/212)) ([80cfd0d](https://github.com/spotify/confidence-resolver/commit/80cfd0d0128af4c65b1ae50539f2b1d0d959c02e))

## [0.5.1](https://github.com/spotify/confidence-resolver/compare/openfeature-provider-js-v0.5.0...openfeature-provider-js-v0.5.1) (2026-01-12)


### Bug Fixes

* **js:** handle missing debug package under nextjs ([#219](https://github.com/spotify/confidence-resolver/issues/219)) ([c4d49fc](https://github.com/spotify/confidence-resolver/commit/c4d49fc6486931e902848f11245c2a4d02af98ff))

## [0.5.0](https://github.com/spotify/confidence-resolver/compare/openfeature-provider-js-v0.4.0...openfeature-provider-js-v0.5.0) (2025-12-19)


### Features

* pluggable materialization ([#211](https://github.com/spotify/confidence-resolver/issues/211)) ([96aea72](https://github.com/spotify/confidence-resolver/commit/96aea72a2dce2e02fdfa4374e4fa245f0efc177b))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * rust-guest bumped from 0.1.11 to 0.1.12

## [0.4.0](https://github.com/spotify/confidence-resolver/compare/openfeature-provider-js-v0.3.0...openfeature-provider-js-v0.4.0) (2025-12-11)


### Features

* **js:** flush assigned when reaching limit ([#145](https://github.com/spotify/confidence-resolver/issues/145)) ([09293ad](https://github.com/spotify/confidence-resolver/commit/09293adc5800f477620905f28539ad45d6a40997))
* WARN logs for errors in evaluations ([#192](https://github.com/spotify/confidence-resolver/issues/192)) ([7a9f157](https://github.com/spotify/confidence-resolver/commit/7a9f1571639e24ea366e643b5b966b1de6fe06bf))

## [0.3.0](https://github.com/spotify/confidence-resolver/compare/openfeature-provider-js-v0.2.0...openfeature-provider-js-v0.3.0) (2025-12-02)


### ⚠ BREAKING CHANGES

* migrate to cdn state fetch, publish logs using client secret ([#166](https://github.com/spotify/confidence-resolver/issues/166))

### Features

* migrate to cdn state fetch, publish logs using client secret ([#166](https://github.com/spotify/confidence-resolver/issues/166)) ([6c8d959](https://github.com/spotify/confidence-resolver/commit/6c8d959f124faa419c1ace103d8832457248eb26))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * rust-guest bumped from 0.1.10 to 0.1.11

## [0.2.0](https://github.com/spotify/confidence-resolver/compare/openfeature-provider-js-v0.1.1...openfeature-provider-js-v0.2.0) (2025-11-24)


### Features

* send js sdk info in resolve request ([#161](https://github.com/spotify/confidence-resolver/issues/161)) ([5cbc7d9](https://github.com/spotify/confidence-resolver/commit/5cbc7d9e2ada26c52298d74faaba50ec6cb4c3e7))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * rust-guest bumped from 0.1.9 to 0.1.10

## [0.1.1](https://github.com/spotify/confidence-resolver-rust/compare/openfeature-provider-js-v0.1.0...openfeature-provider-js-v0.1.1) (2025-11-03)


### Bug Fixes

* handle panics ([#76](https://github.com/spotify/confidence-resolver-rust/issues/76)) ([1ea86ea](https://github.com/spotify/confidence-resolver-rust/commit/1ea86eaa3e64aea5a64086534fe94a155828ef80))

## 0.1.0 (2025-10-24)


### Features

* js local resolver ([#32](https://github.com/spotify/confidence-resolver-rust/issues/32)) ([58893d6](https://github.com/spotify/confidence-resolver-rust/commit/58893d6610b56b5aa6a6250db9e9bb1af506497f))
* **js:** add sticky assignment support through remote resolver fallback ([#48](https://github.com/spotify/confidence-resolver-rust/issues/48)) ([baeff3e](https://github.com/spotify/confidence-resolver-rust/commit/baeff3ec39a084615012d961997949748285ac57))


### Bug Fixes

* **js:** correct current time ([#67](https://github.com/spotify/confidence-resolver-rust/issues/67)) ([260f5e3](https://github.com/spotify/confidence-resolver-rust/commit/260f5e3c937dad99e09db1795c6036f0647514c7))

## 0.0.0 (Initial Version)

* Initial setup for release-please tracking
